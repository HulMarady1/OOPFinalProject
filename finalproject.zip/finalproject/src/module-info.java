/**
 * 
 */
/**
 * @author Eav Sarin
 *
 */
module finalproject {
	requires java.desktop;
	requires java.naming;
}